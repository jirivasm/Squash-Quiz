package com.example.quiz;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    final int NUM_QUESTIONS = 6;

    int currentQuestion = 0;
    View currView;
    int score = 0;
    boolean isSubmitted = true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        currView = findViewById(R.id.quiz_intro);
    }

    public void startSubmitQuestion(View v) {

        Button submitB = findViewById(R.id.startSubmitButton);
        View nextB = findViewById(R.id.nextbutton);
        TextView remaining = findViewById(R.id.remainig_questions);

        //Check answers for questions
        if (currentQuestion == 1)
            checkQuestion1();
        if (currentQuestion == 2)
            checkQuestion2();
        if (currentQuestion == 3)
            checkQuestion3();
        if (currentQuestion == 4)
            checkQuestion4();
        if (currentQuestion == 5)
            checkQuestion5();
        if (currentQuestion == 6)
            checkQuestion6();

        if (currentQuestion == 0) {
            EditText usernameEditText = findViewById(R.id.my_name);
            String sUsername = usernameEditText.getText().toString();
            if (sUsername.matches(""))
                Toast.makeText(this, getResources().getText(R.string.please_enter_name), Toast.LENGTH_SHORT).show();
            else {
                submitB.setBackgroundColor(getResources().getColor(R.color.submitButton));
                remaining.setVisibility(View.VISIBLE);
                nextB.setVisibility(View.GONE);
                currView.setVisibility(View.GONE);
                submitB.setText(R.string.submitAnswer);
                currentQuestion = 1;
                setCurrView();
                remaining.setVisibility(View.VISIBLE);
                remaining.setText(currentQuestion + "/" + NUM_QUESTIONS);
            }
        }
        buttonBelow(currView, submitB);
    }

    public void nextQuestion(View v) {
        if (currentQuestion < 7) {
            Button nextButton = findViewById(R.id.nextbutton);
            TextView remaining = findViewById(R.id.remainig_questions);
            isSubmitted = false;
            nextButton.setVisibility(View.GONE);
            currView.setVisibility(View.GONE);

            currentQuestion++;
            remaining.setText(currentQuestion + "/" + NUM_QUESTIONS);

        } else if (currentQuestion == 7) {

            restartQuiz();
        }
        setCurrView();
    }

    private void setCurrView() {
//
        Button nextB = findViewById(R.id.nextbutton);
        Button submitB = findViewById(R.id.startSubmitButton);
//      Set the visibility for the current question.

        switch (currentQuestion) {

            case 0: {
//              Set The Next to gone so the user can only start the quiz.
                submitB.setText(R.string.start);
                nextB.setVisibility(View.GONE);
                nextB.setText(R.string.next);
                currView = findViewById(R.id.quiz_intro);
                currView.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);

            }
            break;
            case 1: {
                currView = findViewById(R.id.first_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);

            }

            break;
            case 2: {
                currView = findViewById(R.id.second_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);
            }
            break;
            case 3: {
                currView = findViewById(R.id.third_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);
            }

            break;
            case 4: {
                currView = findViewById(R.id.fourth_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);
            }

            break;
            case 5: {
                currView = findViewById(R.id.fifth_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);
            }
            break;
            case 6: {
                nextB.setText(R.string.results);
                currView = findViewById(R.id.sixth_question);
                currView.setVisibility(View.VISIBLE);
                submitB.setVisibility(View.VISIBLE);
                buttonBelow(currView, submitB);

            }
            break;
            case 7: {

                //Set The Next Button Visible and change name to Restart
                nextB.setVisibility(View.VISIBLE);
                nextB.setText(R.string.restart);

                //Set the remaining questions invisible
                currView = findViewById(R.id.remainig_questions);
                currView.setVisibility(View.INVISIBLE);

                //find the total score and set it to visible to display results
                TextView text = findViewById(R.id.total_score);
                text.setVisibility(View.VISIBLE);

                //Get the params of the nextButton and aligned on the screen
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) nextB.getLayoutParams();
                params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, nextB.getId());
                params.addRule(RelativeLayout.ALIGN_PARENT_LEFT, nextB.getId());

                //Save the users name to myActualName and set it to visible
                EditText name = findViewById(R.id.my_name);
                TextView myActualName = findViewById(R.id.this_is_my_name);
                myActualName.setText(name.getText().toString());
                myActualName.setVisibility(View.VISIBLE);

                //calculate final score
                int finalScore = ((score * 100) / 10);

                if (score > 6) {

                    //set the results text and color it
                    text.setText(String.valueOf(finalScore) + "%\n" + getResources().getString(R.string.pass));
                    text.setTextColor(getResources().getColor(R.color.colorAccent));
                    //get the wining image and set it to visible
                    ImageView pass = findViewById(R.id.image_pass);
                    pass.setVisibility(View.VISIBLE);

                    //set the next button below the winning image
                    params.addRule(RelativeLayout.BELOW, pass.getId());
                } else {
                    //set result text and color it
                    text.setText(finalScore + "% \n" + getResources().getString(R.string.fail));
                    text.setTextColor(getResources().getColor(R.color.blue));

                    //get the wining image and set it to visible
                    ImageView fail = findViewById(R.id.image_fail);
                    fail.setVisibility(View.VISIBLE);

                    //set nextButton below failImage
                    params.addRule(RelativeLayout.BELOW, fail.getId());
                }

                submitB.setVisibility(View.GONE);
                break;
            }
        }
    }

    public void buttonBelow(View v, Button belowV) {

        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) belowV.getLayoutParams();
        params.addRule(RelativeLayout.BELOW, v.getId());

        if (currentQuestion != 0) {
            belowV.setText(R.string.submitAnswer);
        }
        if (currentQuestion == 7) {
            belowV.setText(R.string.restart);
        }

    }

    public void checkQuestion1() {
        RadioGroup questions = findViewById(R.id.first_group);
        RadioButton answer = findViewById(R.id.goggles);
        RadioButton answer1 = findViewById(R.id.face_mask);
        RadioButton answer2 = findViewById(R.id.knee_pads);
        RadioButton answer3 = findViewById(R.id.all_of_above);

        if (answer.isChecked()) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 1;
            questions.setEnabled(false);
        } else if (answer1.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer1.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer2.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer2.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer3.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer3.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        }

        if (!questions.isEnabled()) {
            answer.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }
    }

    public void checkQuestion2() {

        RadioGroup questions = findViewById(R.id.second_group);
        RadioButton answer = findViewById(R.id.squash);
        RadioButton answer1 = findViewById(R.id.tennis);
        RadioButton answer2 = findViewById(R.id.badminton);
        RadioButton answer3 = findViewById(R.id.raquetball);

        if (answer.isChecked()) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 1;
            questions.setEnabled(false);
        } else if (answer1.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer1.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer2.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer2.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer3.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer3.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        }

        if (!questions.isEnabled()) {

            answer.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }
    }

    public void checkQuestion3() {

        CheckBox answer = findViewById(R.id.doubleYellow);
        CheckBox answer1 = findViewById(R.id.yellow);
        CheckBox answer2 = findViewById(R.id.tennis_ball);
        CheckBox answer3 = findViewById(R.id.baseball);

        //if the answer checked are correct and none of the others are chequed
        if (answer.isChecked() && answer1.isChecked() && !answer2.isChecked() && !answer3.isChecked()) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 2;
            answer.setEnabled(false);
            answer1.setEnabled(false);
            answer2.setEnabled(false);
            answer3.setEnabled(false);
        }
        else if (answer1.isChecked() || answer.isChecked()) {
            //if only one of the answers are checked
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer.setEnabled(false);
            answer1.setEnabled(false);
            answer2.setEnabled(false);
            answer3.setEnabled(false);
        }
        //if either of the wrong answers are checked
        if (answer2.isChecked() || answer3.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            if(answer2.isChecked())
                answer2.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            if(answer3.isChecked())
                answer3.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));

            answer.setEnabled(false);
            answer1.setEnabled(false);
            answer2.setEnabled(false);
            answer3.setEnabled(false);
        }
        if (!answer.isEnabled()) {
            answer.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            answer1.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }
    }

    public void checkQuestion4() {
        RadioGroup questions = findViewById(R.id.trueorfalse);
        RadioButton answer = findViewById(R.id.is_true);
        RadioButton answer1 = findViewById(R.id.is_false);

        if (answer.isChecked()) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 1;
            questions.setEnabled(false);
        } else if (answer1.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer1.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        }

        if (!questions.isEnabled()) {
            answer.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }
    }

    public void checkQuestion5() {
        RadioGroup questions = findViewById(R.id.fifth_group);
        RadioButton answer3 = findViewById(R.id.eleven);
        RadioButton answer1 = findViewById(R.id.nine);
        RadioButton answer2 = findViewById(R.id.fifteen);
        RadioButton answer = findViewById(R.id.fifty);

        if (answer3.isChecked()) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 1;
            questions.setEnabled(false);
        } else if (answer1.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer1.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer2.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer2.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        } else if (answer.isChecked()) {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            questions.setEnabled(false);
        }

        if (!questions.isEnabled()) {
            answer3.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }

    }

    public void checkQuestion6() {

        EditText answer = findViewById(R.id.sixth_answer);
        String answerToUpper = answer.getText().toString().toUpperCase();
        String correctAnswer = getString(R.string.egypt).toUpperCase();


        if (answerToUpper.equals(correctAnswer)) {
            Toast.makeText(this, R.string.congrats, Toast.LENGTH_SHORT).show();
            score += 4;
            answer.setBackgroundColor(getResources().getColor(R.color.correctAnswer));
            answer.setEnabled(false);
        } else {
            Toast.makeText(this, R.string.wrong, Toast.LENGTH_SHORT).show();
            answer.setBackgroundColor(getResources().getColor(R.color.wrongAnswer));
            answer.setEnabled(false);
        }
        if (!answer.isEnabled()) {
            Button nextB = findViewById(R.id.nextbutton);
            Button submitB = findViewById(R.id.startSubmitButton);
            nextB.setVisibility(View.VISIBLE);
            submitB.setVisibility(View.GONE);
        }
    }

    public void restartQuiz() {
        score = 0;
        currentQuestion = 0;
        Button submitB = findViewById(R.id.startSubmitButton);
        submitB.setText(R.string.start);
        submitB.setBackgroundColor(getResources().getColor(R.color.start_nextButton));
        submitB.setVisibility(View.VISIBLE);
        TextView remaining = findViewById(R.id.remainig_questions);
        TextView name = findViewById(R.id.this_is_my_name);
        name.setVisibility(View.GONE);
        ImageView passImage = findViewById(R.id.image_pass);
        passImage.setVisibility(View.GONE);
        ImageView failImage = findViewById(R.id.image_fail);
        failImage.setVisibility(View.GONE);
        remaining.setVisibility(View.GONE);
        TextView score = findViewById(R.id.total_score);
        score.setVisibility(View.GONE);

        //Reset Next Button
        Button nextB = findViewById(R.id.nextbutton);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) nextB.getLayoutParams();
        params.addRule(RelativeLayout.BELOW, submitB.getId());
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, nextB.getId());
        params.addRule(RelativeLayout.ALIGN_PARENT_LEFT, 0);

        //Resetting Question#1
        RadioGroup question1 = findViewById(R.id.first_group);
        RadioButton question1answer = findViewById(R.id.goggles);
        RadioButton question1answer1 = findViewById(R.id.face_mask);
        RadioButton question1answer2 = findViewById(R.id.knee_pads);
        RadioButton question1answer3 = findViewById(R.id.all_of_above);
        question1answer.setBackgroundColor(Color.WHITE);
        question1answer1.setBackgroundColor(Color.WHITE);
        question1answer2.setBackgroundColor(Color.WHITE);
        question1answer3.setBackgroundColor(Color.WHITE);
        question1.setEnabled(true);

        //Resetting Question #2
        RadioGroup question2 = findViewById(R.id.second_group);
        RadioButton question2answer = findViewById(R.id.badminton);
        RadioButton question2answer1 = findViewById(R.id.raquetball);
        RadioButton question2answer2 = findViewById(R.id.tennis);
        RadioButton question2answer3 = findViewById(R.id.squash);
        question2answer.setBackgroundColor(Color.WHITE);
        question2answer1.setBackgroundColor(Color.WHITE);
        question2answer2.setBackgroundColor(Color.WHITE);
        question2answer3.setBackgroundColor(Color.WHITE);
        question2.setEnabled(true);

        //Resetting question #3
        CheckBox question3answer = findViewById(R.id.doubleYellow);
        CheckBox question3answer1 = findViewById(R.id.yellow);
        CheckBox question3answer2 = findViewById(R.id.tennis_ball);
        CheckBox question3answer3 = findViewById(R.id.baseball);
        question3answer.setBackgroundColor(Color.WHITE);
        question3answer1.setBackgroundColor(Color.WHITE);
        question3answer2.setBackgroundColor(Color.WHITE);
        question3answer3.setBackgroundColor(Color.WHITE);
        question3answer.setEnabled(true);
        question3answer1.setEnabled(true);
        question3answer2.setEnabled(true);
        question3answer3.setEnabled(true);

        //Resetting #4
        RadioGroup question4 = findViewById(R.id.trueorfalse);
        RadioButton question4answer = findViewById(R.id.is_true);
        RadioButton question4answer1 = findViewById(R.id.is_false);
        question4answer.setBackgroundColor(Color.WHITE);
        question4answer1.setBackgroundColor(Color.WHITE);
        question4.setEnabled(true);

        //Resetting #5
        RadioGroup question5 = findViewById(R.id.fifth_group);
        RadioButton question5answer3 = findViewById(R.id.eleven);
        RadioButton question5answer1 = findViewById(R.id.nine);
        RadioButton question5answer2 = findViewById(R.id.fifteen);
        RadioButton question5answer = findViewById(R.id.fifty);

        question5answer3.setBackgroundColor(Color.WHITE);
        question5answer1.setBackgroundColor(Color.WHITE);
        question5answer2.setBackgroundColor(Color.WHITE);
        question5answer.setBackgroundColor(Color.WHITE);
        question5.setEnabled(true);

        //Resetting #6
        EditText question6 = findViewById(R.id.sixth_answer);
        question6.setText("");
        question6.setHint(R.string.hintQ6);
        question6.setEnabled(true);
        question6.setBackgroundColor(Color.WHITE);

        currView.setVisibility(View.GONE);
        setCurrView();
    }


}

